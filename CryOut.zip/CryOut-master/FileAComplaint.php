<?php

//if(isset($_POST['type']))
error_reporting(0);
//print_r($_POST);
// die;
//}

?>
<!DOCTYPE html>
<?php
		require 'connect.inc.php';
		require 'complaintSqlFunctions.php';
		require_once 'FileAComplaint.html';

?>
<html>
    <head>
        <title>File A Complaint!</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="People can file complaints on this page and ask for help">
        <meta name="keywords" content="Complaint, Help, CryOut">
        <meta name="author" content="Shreya">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/stylesheet.css" rel="stylesheet">
    </head>
    <body>		
		
    </body>
</html>
